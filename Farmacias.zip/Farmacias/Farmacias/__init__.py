def views(request):
    return None